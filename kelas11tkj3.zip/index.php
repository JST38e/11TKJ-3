<?php include 'config/database.php'; ?>
<!DOCTYPE html>
<html lang="id">
<head>
    <title>Kelas 11 TKJ 3</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>Selamat Datang di Website Kelas 11 TKJ 3</h1>
    <nav>
        <a href="index.php">Beranda</a>
        <a href="pages/anggota.php">Anggota Kelas</a>
        <a href="pages/galeri.php">Galeri</a>
        <a href="login.php">Login</a>
    </nav>
    <p>Website ini berisi informasi tentang kelas kami!</p>
</body>
</html>
