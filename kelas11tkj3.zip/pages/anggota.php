<?php include '../config/database.php'; ?>
<!DOCTYPE html>
<html lang="id">
<head>
    <title>Anggota Kelas</title>
</head>
<body>
    <h2>Daftar Siswa</h2>
    <table border="1">
        <tr>
            <th>No</th>
            <th>Nama</th>
            <th>NIS</th>
        </tr>
        <?php
        $result = mysqli_query($conn, "SELECT * FROM siswa");
        $no = 1;
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr>
                    <td>{$no}</td>
                    <td>{$row['nama']}</td>
                    <td>{$row['nis']}</td>
                  </tr>";
            $no++;
        }
        ?>
    </table>
</body>
</html>
